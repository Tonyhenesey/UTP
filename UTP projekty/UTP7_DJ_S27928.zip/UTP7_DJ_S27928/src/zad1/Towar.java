package zad1;
public class Towar {
    private int id_towaru;
    private double waga;

    public Towar(int id_towaru, double waga) {
        this.id_towaru = id_towaru;
        this.waga = waga;
    }

    public double getWaga() {
        return waga;
    }
}
