package zad1;

import java.util.ArrayList;
import java.util.List;

public class Magazyn {
    private List<Towar> towary = new ArrayList<>();
    private static final Object object = new Object();

    public void dodajTowar(Towar towar) {
        synchronized (object) {
            towary.add(towar);
            int liczbaTowarow = towary.size();
            if (liczbaTowarow % 100 == 0) {
                System.out.println("policzono wage " + liczbaTowarow + " towarow");
            }
        }
    }
    public double obliczWage() {
        synchronized (object) {
            double sumaWag = 0;
            for (Towar towar : towary) {
                sumaWag += towar.getWaga();
            }
            return sumaWag;
        }
    }
}