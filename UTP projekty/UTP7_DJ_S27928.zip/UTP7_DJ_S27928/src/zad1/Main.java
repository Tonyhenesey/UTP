/**
 *
 *  @author Dominiczak Jakub S27928
 *
 */

package zad1;

public class Main {
  public static void main(String[] args) {
    Magazyn magazyn = new Magazyn();
    Reader czytelnik = new Reader("../Towary.txt", magazyn);

    czytelnik.start();

    try {
      czytelnik.join();
    } catch (InterruptedException e) {
      e.printStackTrace();
    }

    double sumaWag = magazyn.obliczWage();
    System.out.println("waga wszystkich towarów: " + sumaWag);

  }
}

