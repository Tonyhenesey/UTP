package zad1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Reader extends Thread {
    private final String sciezka;
    private final Magazyn magazyn;

    public Reader(String sciezka, Magazyn magazyn) {
        this.sciezka = sciezka;
        this.magazyn = magazyn;
    }

    @Override
    public void run() {
        int liczbaObiektow = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(sciezka))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] split = line.split(" ");
                if (split.length >= 2) {
                    int id_towaru = Integer.parseInt(split[0]);
                    double waga = Double.parseDouble(split[1].replace(',', '.'));

                    Towar towar = new Towar(id_towaru, waga);
                    magazyn.dodajTowar(towar);

                    liczbaObiektow++;

                    if (liczbaObiektow % 200 == 0) {
                        System.out.println("utworzono " + liczbaObiektow + " obiektów");
                    }
                } else {
                    System.out.println("Błędny format: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
