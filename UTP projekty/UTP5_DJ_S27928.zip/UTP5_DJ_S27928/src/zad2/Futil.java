package zad2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

public class Futil {
    public static void processDir(String dirName, String fanme){
        Path dirPath = Paths.get(dirName);
        Path fname = Paths.get(fanme);

        try {
            Files.deleteIfExists(fname);
            BufferedWriter writer = Files.newBufferedWriter(fname, StandardCharsets.UTF_8);
            Files.walkFileTree(dirPath,new SimpleFileVisitor<Path>(){
                public FileVisitResult visitFile(Path file, BasicFileAttributes attributes) throws IOException{
                    if (Files.isRegularFile(file) && file.toString().endsWith(".txt")){
                        BufferedReader bufferedReader = Files.newBufferedReader(file, Charset.forName("Cp1250"));

                        String line;
                        while ((line=bufferedReader.readLine())!=null){
                            writer.write(line);
                            writer.newLine();
                        }
                        bufferedReader.close();
                    }
                    return FileVisitResult.CONTINUE;
                }
            });
            writer.close();
            System.out.println("Zapisano w: " + fanme);

        } catch (IOException e) {
            System.out.println("Bład przetwarzania");
        }
    }
}
