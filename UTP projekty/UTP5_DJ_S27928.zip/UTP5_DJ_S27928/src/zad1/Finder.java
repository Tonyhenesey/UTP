/**
 * @author Dominiczak Jakub S27928
 */

package zad1;


import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Finder {
    private String fname;

    public Finder(String fname) {
        this.fname = fname;
    }

    public int getIfCount() throws IOException {
        FileReader fileReader = new FileReader(fname);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        int ifCount = 0;
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            if (line.trim().startsWith("if")) {
                ifCount++;
            }
        }
        bufferedReader.close();
        fileReader.close();
        return ifCount;
    }


    public int getStringCount(String word) throws IOException {
        FileReader fileReader = new FileReader(fname);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        int stringCount = 0;
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            if (line.contains(word)) {
                stringCount++;
            }
        }
        bufferedReader.close();
        fileReader.close();
        return stringCount;
    }
}
