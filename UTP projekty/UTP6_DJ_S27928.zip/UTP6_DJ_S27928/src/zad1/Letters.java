package zad1;

import java.util.ArrayList;
import java.util.List;

public class Letters implements Runnable {

    private String let;
    private List<Thread> threads;


    public Letters(String let) {
        this.let = let;
        this.threads = new ArrayList<>();
        for (int i = 0; i < let.length(); i++) {
            char letter = let.charAt(i);
            Thread thread = new Thread(()->run(),"Thread " + letter);
            threads.add(thread);
        }
    }
    public List<Thread> getThreads() {
        return threads;
    }

        @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            for (char letter : let.toCharArray()) {
                System.out.print(letter);
                try {
                    Thread.sleep(1000);

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
    }
}
