/**
 *
 *  @author Dominiczak Jakub S27928
 *
 */

package zad3;


import javax.swing.*;

public class Main {

  public static void main(String[] args) {
    SwingUtilities.invokeLater(()->new TaskManager());
  }
}
