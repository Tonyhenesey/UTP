package zad3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class TaskManager extends JFrame {

    private DefaultListModel<Future<String>> taskListModel;
    private JList<Future<String>> taskList;

    private ExecutorService executorService;

    public TaskManager() {
        setTitle("Task Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        taskListModel = new DefaultListModel<>();
        taskList = new JList<>(taskListModel);

        JScrollPane scrollPane = new JScrollPane(taskList);
        add(scrollPane, BorderLayout.CENTER);

        JButton addButton = new JButton("Add Task");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addTask();
            }
        });

        JButton cancelButton = new JButton("Cancel Task");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelSelectedTask();
            }
        });

        JButton showResultButton = new JButton("Show Selected Task");
        showResultButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showResultOfSelectedTask();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.CYAN);
        buttonPanel.setLayout(new GridLayout(3, 1));
        buttonPanel.add(addButton);
        buttonPanel.add(cancelButton);
        buttonPanel.add(showResultButton);

        add(buttonPanel, BorderLayout.SOUTH);

        executorService = Executors.newFixedThreadPool(5);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void addTask() {
        Callable<String> task = () -> {
            Thread.sleep(5000);
            return "Task completed!";
        };

        Future<String> futureTask = executorService.submit(task);
        taskListModel.addElement(futureTask);
    }

    private void cancelSelectedTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            Future<String> selectedTask = taskListModel.getElementAt(selectedIndex);
            selectedTask.cancel(true);
            updateTaskList();
        }
    }

    private void showResultOfSelectedTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            Future<String> selectedTask = taskListModel.getElementAt(selectedIndex);
            if (selectedTask.isDone()) {
                try {
                    String result = selectedTask.get();
                    JOptionPane.showMessageDialog(TaskManager.this, result, "Task Result", JOptionPane.INFORMATION_MESSAGE);
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(TaskManager.this, "Task not completed.", "Task Not Completed", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private void updateTaskList() {
        SwingUtilities.invokeLater(() -> taskList.updateUI());
    }

}

