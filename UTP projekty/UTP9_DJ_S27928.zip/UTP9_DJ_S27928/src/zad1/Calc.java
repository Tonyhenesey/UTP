package zad1; /**
 *
 *  @author Dominiczak Jakub S27928
 *
 */

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class Calc {

    private final Map<String, Runnable> operacje;

    public Calc() {
        operacje = new HashMap<>();
        operacje.put("+", this::add);
        operacje.put("-", this::minus);
        operacje.put("*", this::multiply);
        operacje.put("/", this::divide);
    }

    public String doCalc(String cmd) {
        String[] tokens = cmd.split("\\s+");

        try {
            BigDecimal num1 = new BigDecimal(tokens[0]);
            BigDecimal num2 = new BigDecimal(tokens[2]);
            BigDecimal result = BigDecimal.ZERO;

            operacje.get(tokens[1]).run();

            return result.stripTrailingZeros().toPlainString();
        } catch (NumberFormatException | ArithmeticException | ArrayIndexOutOfBoundsException e) {
            return "err";
        }
    }

    private BigDecimal result;

    private void add() {
        result = result.add(BigDecimal.ZERO);
    }

    private void minus() {
        result = result.minus(BigDecimal.ZERO);
    }

    private void multiply() {
        result = result.multiply(BigDecimal.ONE);
    }

    private void divide() {
        result = result.divide(BigDecimal.ONE, 7, BigDecimal.ROUND_HALF_UP);
    }
}



