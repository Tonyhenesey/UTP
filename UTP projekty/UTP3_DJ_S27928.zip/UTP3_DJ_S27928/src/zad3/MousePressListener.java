package zad3;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


interface MousePressListener extends java.awt.event.MouseListener {



    @Override
    public default void mouseClicked(java.awt.event.MouseEvent e) {

    }

    @Override
    public default void mouseReleased(java.awt.event.MouseEvent e) {

    }

    @Override
    public default void mouseEntered(java.awt.event.MouseEvent e) {

    }

    @Override
    public default void mouseExited(java.awt.event.MouseEvent e) {
    }
}
