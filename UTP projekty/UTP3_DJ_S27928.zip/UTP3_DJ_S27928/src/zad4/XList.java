package zad4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

public class XList<T> extends ArrayList <T> {


    public XList(Object...objects){
        this.addAll(XList.of(objects));
    }

    public XList(Collection<? extends T> c) {
        super(c);
    }

    public static <T> XList<T> of(Object... objects) {
        XList<T> xList = new XList<>();

        boolean combine = objects.length > 1 &&
                Arrays.stream(objects).allMatch(object -> object instanceof Collection || object.getClass().isArray());

        Arrays.stream(objects).forEach(object -> {
            if (object instanceof Collection && !combine) {
                ((Collection<?>) object).forEach(o -> xList.addAll(XList.of(o)));
            } else if (object.getClass().isArray() && !combine) {
                Arrays.stream((Object[]) object).forEach(o -> xList.addAll(XList.of(o)));
            } else {
                xList.add(combine ? (T) XList.of(object) : (T) object);
            }
        });

        return xList;
    }




    public static XList<String> charsOf(String s){
        List<String> listChar = new ArrayList<>();
            int length = s.length();
            for (int i = 0; i < length; i++) {
                listChar.add(String.valueOf(s.charAt(i)));
            }
            return XList.of(listChar);
        }

        public static XList<String> tokensOf(String s){
        return XList.tokensOf(s, "\\s+");
        }
        public static XList<String> tokensOf( String s, String seperator){
        return XList.of(s.split(seperator));
        }

        public XList<Integer> union(Object...objects){
        XList xList = new XList(this);
        xList.addAll(XList.of(objects));
        return xList;
        }

        public XList diff(Object...objects){
        XList xList = new XList(this);
        xList.removeAll(XList.of(objects));
        return xList;
        }
        public XList<T> unique(){
        XList xList = new XList();
        this.forEach(p->{
            if (!xList.contains(p)){
                xList.add(p);
            }
        });
        return xList;
        }
    public XList<XList<T>> combine() {
        XList<XList<T>> xLists = new XList<>();
        combineHelper(xLists, new XList<>(), 0);
        return xLists;
    }

    private void combineHelper(XList<XList<T>> xLists, XList<T> current, int index) {
        if (index == current.size()) {
            xLists.add(new XList<>(current));
            return;
        }
        T element = get(index);
        if (element instanceof Collection) {
            Collection<T> collection = (Collection<T>) element;
            Object[] items = collection.toArray();
            for (int i = 0; i < items.length; i++) {
                T item = (T) items[i];
                current.add(item);
                combineHelper(xLists, current, index + 1);
                current.remove(current.size() - 1);
            }
        } else {
            T item = (T) element;
            current.add(item);
            combineHelper(xLists, current, index + 1);
            current.remove(current.size() - 1);
        }

    }
    public String join(String separator) {
        return this.stream()
                .map( Object::toString )
                .collect( Collectors.joining(separator));
    }

    public String join() {
        return join("");
    }



    public <R> XList<R> collect(Function<T, R> function) {
        XList<R> result = new XList<>();
        for (T element : this) {
            result.add(function.apply(element));
        }
        return result;
    }




    public void forEachWithIndex(BiConsumer<T, Integer> action) {
        for (int i = 0; i < size(); i++) {
            action.accept(this.get(i), i);
        }
    }
    private XList(){
    }


}
