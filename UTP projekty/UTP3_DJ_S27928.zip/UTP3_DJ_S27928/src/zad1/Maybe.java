package zad1;

import java.util.NoSuchElementException;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Maybe<C> {
    private C value;

    private Maybe(C value) {
        this.value = value;
    }

    public static <O> Maybe<O> of(O value) {
        if (value == null) {
            return new Maybe<>(null);
        } else {
            return new Maybe<>(value);
        }
    }

    public void ifPresent(Consumer<C> cons) {
        if (value != null) {
            cons.accept(value);
        }
    }

    public <U> Maybe<U> map(Function<C, U> func) {
        if (value != null) {
            U result = func.apply(value);
            return of(result);
        } else {
            return new Maybe<>(null);
        }
    }

    public C get() {
        if (value != null) {
            return value;
        } else {
            throw new NoSuchElementException("maybe is empty");
        }
    }

    public boolean isPresent() {
        return value != null;
    }

    public C orElse(C defVal) {
        return value != null ? value : defVal;
    }

    public Maybe<C> filter(Predicate<C> pred) {
        if (value != null && pred.test(value)) {
            return this;
        } else {
            return new Maybe<>(null);
        }
    }

    @Override
    public String toString() {
        if (value != null) {
            return "Maybe has value " + value;
        } else {
            return "Maybe is empty";
        }
    }
}
