package zad2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class InputConverter<T> {
    private T data;

    public InputConverter(T data) {
        this.data = data;
    }

    public <T> T convertBy(Function... functions) {
        Object input = data;
        Object result = null;

        for (Function f : functions) {
            result = f.apply(input);
            input = result;
        }

        return (T) result;
    }

    public static List<String> flines(String filename) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lines;
    }

    public static String join(List<String> strings) {
        return String.join("", strings);
    }

    public static List<Integer> collectInts(String text) {
        List<Integer> ints = new ArrayList<>();
        String[] words = text.split("\\s+");
        for (String word : words) {
            try {
                ints.add(Integer.parseInt(word));
            } catch (NumberFormatException e) {
                // Ignore non-integer values
            }
        }
        return ints;
    }

    public static int sum(List<Integer> numbers) {
        return numbers.stream().mapToInt(Integer::intValue).sum();
    }
}
