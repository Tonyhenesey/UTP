/**
 *
 *  @author Dominiczak Jakub S27928
 *
 */

package zad2;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*<--
 *  niezbędne importy
 */
public class Main {
  public static void main(String[] args) {
      Function<String, List<String>> flines = fileName -> {
          List<String> fileResult = new ArrayList<>();
          try{
              BufferedReader br = new BufferedReader(new FileReader(fileName));
              String line;
              while((line = br.readLine()) != null && !line.isEmpty())
                  fileResult.add(line);

              return fileResult;
          }catch (IOException e){
              e.printStackTrace();
              return null;
          }
      };

      Function<List<String>, String> join = arrayElements -> String.join("", arrayElements);

      Function<String, List<Integer>> collectInts = arrayText -> {
          Pattern pattern = Pattern.compile("\\d+");
          Matcher matcher = pattern.matcher(arrayText);
          List<Integer> foundNuumbers = new ArrayList<>();

          while(matcher.find()){
              String numberString = matcher.group();
              int num = Integer.parseInt(numberString);
              foundNuumbers.add(num);
          }

          return foundNuumbers;
      };

      Function<List<Integer>, Integer> sum = ints -> {
          int sum1 = ints.stream().mapToInt(Integer::intValue).sum();
          return sum1;
      };

          String fname = System.getProperty("user.home") + "/LamComFile.txt";
          InputConverter<String> fileConv = new InputConverter<>(fname);
          List<String> lines = fileConv.convertBy(flines);
          String text = fileConv.convertBy(flines, join);
          List<Integer> ints = fileConv.convertBy(flines, join, collectInts);
          Integer sumints = fileConv.convertBy(flines, join, collectInts, sum);

          System.out.println(lines);
          System.out.println(text);
          System.out.println(ints);
          System.out.println(sumints);

          List<String> arglist = Arrays.asList(args);
          InputConverter<List<String>> slistConv = new InputConverter<>(arglist);
          sumints = slistConv.convertBy(join, collectInts, sum);
          System.out.println(sumints);

      }
  }

